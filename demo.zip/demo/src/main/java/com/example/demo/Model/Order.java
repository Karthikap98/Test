package com.example.demo.Model;

public class Order {

	String orderId;
	String productId;
	Double qty;
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public Double getQty() {
		return qty;
	}
	public void setQty(Double qty) {
		this.qty = qty;
	}
	public Order(String orderId, String productId, Double qty) {
		super();
		this.orderId = orderId;
		this.productId = productId;
		this.qty = qty;
	}
	
	
}
