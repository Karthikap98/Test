package com.example.demo.Model;

import java.util.List;

import org.springframework.stereotype.Component;

@Component
public class OrderShipmentPojo {
	
	Order order;
	Shipment shipment;
	
	

	public OrderShipmentPojo() {
		super();
	}


	public Order getOrder() {
		return order;
	}


	public void setOrder(Order order) {
		this.order = order;
	}


	public Shipment getShipment() {
		return shipment;
	}


	public void setShipment(Shipment shipment) {
		this.shipment = shipment;
	}



	public OrderShipmentPojo(Order order, Shipment shipment) {
		super();
		this.order = order;
		this.shipment = shipment;
	}


	
	
	
	
	

}
