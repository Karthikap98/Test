package com.example.demo.Model;

import java.time.LocalDate;


public class AvailCap {
 
	String storeNo;
    String productId;
    Integer reqQty;
    LocalDate EDD;
	public String getStoreNo() {
		return storeNo;
	}
	public void setStoreNo(String storeNo) {
		this.storeNo = storeNo;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public Integer getReqQty() {
		return reqQty;
	}
	public void setReqQty(Integer reqQty) {
		this.reqQty = reqQty;
	}
	public LocalDate getEDD() {
		return EDD;
	}
	public void setEDD(LocalDate eDD) {
		EDD = eDD;
	}
	public AvailCap(String storeNo, String productId, Integer reqQty, LocalDate eDD) {
		super();
		this.storeNo = storeNo;
		this.productId = productId;
		this.reqQty = reqQty;
		EDD = eDD;
	}
	public AvailCap(String storeNo, String productId, Integer reqQty) {
		super();
		this.storeNo = storeNo;
		this.productId = productId;
		this.reqQty = reqQty;
	}
	public AvailCap() {
		super();
	}
    

}
