package com.example.demo.Controller;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Model.AvailCap;
import com.example.demo.Model.Order;
import com.example.demo.Model.OrderShipmentPojo;
import com.example.demo.Model.Shipment;
import com.example.demo.Model.Supply;
import com.example.demo.Service.AvailCapService;

@RestController
@EnableAsync
public class ProductSort {
	
	@Autowired
	AvailCapService availCapService;
	
	@Autowired
	OrderShipmentPojo osp;
	
	@PostMapping("/getDatesByservice")
	public AvailCap getDatesByservice(@RequestBody AvailCap availCap){
		
		
		
		CompletableFuture<LocalDate> avail = availCapService.getAvailability(availCap);
		CompletableFuture<LocalDate> cap = availCapService.getCapacity(availCap);
		System.out.println(avail);
		System.out.println(cap);
		
		try {
			if(avail.get().isAfter(cap.get())) {
				availCap.setEDD(avail.get());
				return availCap;
			} else if(avail.get().isBefore(cap.get())) {
				availCap.setEDD(cap.get());
				return availCap;
			}
		} catch (InterruptedException | ExecutionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return availCap;
		
	}
	
	
	
	
	
	@GetMapping("/getOrderDetails/{orderId}")
	public OrderShipmentPojo getOrderDetails( @PathVariable("orderId") String orderId){
		
		CompletableFuture<Order> avail = availCapService.getOrder(orderId);
		CompletableFuture<Shipment> cap = availCapService.getShipment(orderId);
		System.out.println(avail);
		System.out.println(cap);
		
		List<Object> list = new ArrayList<Object>();
		
		List<Object> OrderShipmentPojo;
		
		
		try {
			if(avail.get()!=null && cap.get()!=null) {
			
			osp.setOrder(avail.get());
			osp.setShipment(cap.get());
			return osp;
			}
		} catch (InterruptedException | ExecutionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return osp;
		
	}
	
	
	
	
	
	@PostMapping("/updateSupply")
	public Supply getDatesByservice(@RequestBody Supply supply){
		
		LocalTime lt = supply.getUpdateTimeStamp().toLocalTime();
		
		LocalDate d =LocalDate.of(2021, 03, 16);
		LocalTime t1 = LocalTime.of(8, 53, 48, 616);
		LocalTime t2 = LocalTime.of(8, 59, 48, 616);
		LocalTime t3 = LocalTime.of(9, 10, 48, 616);
		LocalTime t4 = LocalTime.of(9, 10, 48, 616);
		
		Supply s1 = new Supply("Product1",LocalDateTime.of(d, t1),10);

		Supply s2 = new Supply ("Product2",LocalDateTime.of(d, t2),5);

		Supply s3 = new  Supply ("Product3",LocalDateTime.of(d, t3),30);

		Supply s4 = new Supply ("Product4",LocalDateTime.of(d, t4),20);
		
		List<Supply> supplyList = new ArrayList<>();
		supplyList.add(s1);
		supplyList.add(s2);
		supplyList.add(s3);
		supplyList.add(s4);
		
	
	for(Supply s : supplyList) {
		if(lt.isBefore(s.getUpdateTimeStamp().toLocalTime()) && supply.getProductId().equalsIgnoreCase(s.getProductId())){
			supply.setStatus("Out Of Sync Update");
			return supply;
		}else if(lt.isAfter(s.getUpdateTimeStamp().toLocalTime()) && supply.getProductId().equalsIgnoreCase(s.getProductId())) {
			supply.setStatus("Updated");
			supply.setQuantity((s.getQuantity())+(supply.getQuantity()));
			return supply;
		}
	}
	return supply;
	}

}
