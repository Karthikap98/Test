package com.example.demo.Service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;

import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.example.demo.Model.AvailCap;
import com.example.demo.Model.Availability;
import com.example.demo.Model.Capacity;
import com.example.demo.Model.Order;
import com.example.demo.Model.Shipment;

@Service
public class AvailCapService {

	LocalDate d1= LocalDate.of(2021, 10, 29);
	LocalDate d2= LocalDate.of(2021, 10, 26);
	LocalDate d3= LocalDate.of(2021, 10, 25);
	LocalDate d4= LocalDate.of(2021, 10, 28);
	LocalDate d5= LocalDate.of(2021, 10, 30);
	
	@Async
	public CompletableFuture<LocalDate> getAvailability(AvailCap availCap) {
		
		Availability a1 = new Availability ("Store001", "Prod1", d1, 1.0);

	    Availability a2 = new  Availability ("Store001", "Prod2", d2, 3.0);

	    Availability a3= new Availability ("Store001", "Prod3", d3, 2.0);
		
		List<Availability> availList = new ArrayList<>();
		availList.add(a1);
		availList.add(a2);
		availList.add(a3);
		
		
		return CompletableFuture.completedFuture(
				availList.stream()
				.filter(a->a.getStoreNo().equals(availCap.getStoreNo()))
				.filter(a-> a.getProductId().equals(availCap.getProductId()))
				.map(a->a.getDate())
				.findFirst().get());
		
	}

	@Async
	public CompletableFuture<LocalDate> getCapacity(AvailCap availCap) {
		
		Capacity c1 = new Capacity("Store001", "Prod1", d4, 1.0);

		Capacity c2 = new Capacity ("Store001", "Prod2",d5, 3.0);

		Capacity c3 = new Capacity ("Store001", "Prod3", d1, 2.0);
		List<Capacity> capList = new ArrayList<>();
		capList.add(c1);
		capList.add(c2);
		capList.add(c3);
		
		
		
		return CompletableFuture.completedFuture(
				capList.stream()
				.filter(c->c.getStoreNo().equalsIgnoreCase(availCap.getStoreNo()))
				.filter(c->c.getProductId().equals(availCap.getProductId()))
				.map(c->c.getDate()).findFirst().get());
		
	
	}


	@Async
	public CompletableFuture<Order> getOrder(String orderId) {
		
		Order o1 = new	Order ("Order1", "Prod1", 2.0);

	    Order o2 = new Order ("Order2", "Prod1", 2.0);
	    
	    List<Order> order = new ArrayList<>();
	    order.add(o1);
	    order.add(o2);
	    
	    return CompletableFuture.completedFuture(
	    		order.stream().filter(o->o.getOrderId().equalsIgnoreCase(orderId))
	    		.findFirst().get());
	    

	}
	
	@Async
	public CompletableFuture<Shipment> getShipment(String orderId) {

		LocalDate d1 = LocalDate.of(2021, 02, 19);

		Shipment s1 = new  Shipment ("Order1", "Ship1", "Prod1" ,d1, 2.0);

		Shipment s2 = new  Shipment ("Order2", "Ship2", "Prod1" ,d1, 2.0);
		
		List<Shipment> shipment = new ArrayList<>();
		shipment.add(s1);
		shipment.add(s2);
	    
	    return CompletableFuture.completedFuture(
	    		shipment.stream().filter(o->o.getOrderId().equalsIgnoreCase(orderId))
	    		.findFirst().get());
	    	}
	

}
