package com.example.demo.Model;

public class OrderShipment {

}
