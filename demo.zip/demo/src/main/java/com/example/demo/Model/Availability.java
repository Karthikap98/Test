package com.example.demo.Model;

import java.time.LocalDate;

public class Availability {

	public Availability(String storeNo, String productId, LocalDate date,Double availQty) {
		super();
		this.storeNo = storeNo;
		this.productId = productId;
		this.date = date;
		this.availQty = availQty;
		
		
	}
	public String getStoreNo() {
		return storeNo;
	}
	public void setStoreNo(String storeNo) {
		this.storeNo = storeNo;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public Double getAvailQty() {
		return availQty;
	}
	public void setAvailQty(Double availQty) {
		this.availQty = availQty;
	}
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}
	String storeNo ;
	String productId;
	LocalDate date;
	Double availQty;
	
	
	
}
