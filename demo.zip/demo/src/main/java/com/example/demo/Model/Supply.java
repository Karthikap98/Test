package com.example.demo.Model;

import java.time.LocalDateTime;

public class Supply {

	String productId;
	LocalDateTime updateTimeStamp;
	Integer quantity;
	String status;
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public LocalDateTime getUpdateTimeStamp() {
		return updateTimeStamp;
	}
	public void setUpdateTimeStamp(LocalDateTime updateTimeStamp) {
		this.updateTimeStamp = updateTimeStamp;
	}
	public Integer getQuantity() {
		return quantity;
	}
	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Supply(String productId, LocalDateTime updateTimeStamp, Integer quantity, String status) {
		super();
		this.productId = productId;
		this.updateTimeStamp = updateTimeStamp;
		this.quantity = quantity;
		this.status = status;
	}
	public Supply(String productId, LocalDateTime updateTimeStamp, Integer quantity) {
		super();
		this.productId = productId;
		this.updateTimeStamp = updateTimeStamp;
		this.quantity = quantity;
	}
	public Supply() {
		super();
	}
	
	
}
